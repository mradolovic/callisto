# Raspberry-Pi-3-Altium-Template

This Project should simplifiy the design process of modules for raspberry pi 2 and 3, model B.
It uses the 40 pin GPIO connector to access the rpi GPIOs. The dimensions of the board are based on the image below which comes from the raspberry pi developers. 

Thanks to Matheus for his feedback. The design is now tested a few times and was produced successfully.

Here is a preview on how it looks in 3D, on top of an raspberry pi.

![Alt text](images/3d.png?raw=true "PCB in 3D view")

The original drawing of the raspberry dimensions.

![Alt text](images/drawing1.png?raw=true "Original drawing of model B")

Dimensions from template pcb, made by altiums draftsman

![Alt text](images/drawing2.png?raw=true "draftsman dimensioning")

kindly
# Nils


